--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-02-21 17:56:10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 16410)
-- Name: Outreach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Outreach" (
    "outreach_ID" integer NOT NULL,
    "review_ID" integer NOT NULL,
    call_history text NOT NULL,
    resolution_status smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public."Outreach" OWNER TO postgres;

--
-- TOC entry 4806 (class 0 OID 0)
-- Dependencies: 221
-- Name: COLUMN "Outreach".resolution_status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Outreach".resolution_status IS '0 = not resolved
1 = resolved';


--
-- TOC entry 222 (class 1259 OID 16428)
-- Name: Outreach_outreach_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Outreach" ALTER COLUMN "outreach_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Outreach_outreach_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 4799 (class 0 OID 16410)
-- Dependencies: 221
-- Data for Name: Outreach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Outreach" ("outreach_ID", "review_ID", call_history, resolution_status) FROM stdin;
\.


--
-- TOC entry 4807 (class 0 OID 0)
-- Dependencies: 222
-- Name: Outreach_outreach_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Outreach_outreach_ID_seq"', 1, false);


--
-- TOC entry 4650 (class 2606 OID 16417)
-- Name: Outreach Outreach_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Outreach"
    ADD CONSTRAINT "Outreach_pkey" PRIMARY KEY ("outreach_ID");


--
-- TOC entry 4651 (class 1259 OID 16430)
-- Name: idx_outreach_reviewID; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_outreach_reviewID" ON public."Outreach" USING btree ("review_ID") WITH (deduplicate_items='true');


--
-- TOC entry 4652 (class 1259 OID 16436)
-- Name: idx_outreach_unresolved; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_outreach_unresolved ON public."Outreach" USING btree (resolution_status) WITH (deduplicate_items='true');


--
-- TOC entry 4653 (class 2606 OID 16418)
-- Name: Outreach review_ID; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Outreach"
    ADD CONSTRAINT "review_ID" FOREIGN KEY ("review_ID") REFERENCES public."Reviews"("review_ID") ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2025-02-21 17:56:10

--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-02-21 17:58:54

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 16389)
-- Name: Reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Reviews" (
    "review_ID" integer NOT NULL,
    platform character varying(255) NOT NULL,
    rating integer NOT NULL,
    content text NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public."Reviews" OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16388)
-- Name: Reviews_review_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Reviews" ALTER COLUMN "review_ID" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Reviews_review_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 4799 (class 0 OID 16389)
-- Dependencies: 218
-- Data for Name: Reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Reviews" ("review_ID", platform, rating, content, "timestamp") FROM stdin;
\.


--
-- TOC entry 4805 (class 0 OID 0)
-- Dependencies: 217
-- Name: Reviews_review_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Reviews_review_ID_seq"', 1, false);


--
-- TOC entry 4649 (class 2606 OID 16395)
-- Name: Reviews Reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Reviews"
    ADD CONSTRAINT "Reviews_pkey" PRIMARY KEY ("review_ID");


--
-- TOC entry 4650 (class 1259 OID 16433)
-- Name: idx_reviews_platform; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_platform ON public."Reviews" USING btree (platform) WITH (deduplicate_items='true');


--
-- TOC entry 4651 (class 1259 OID 16432)
-- Name: idx_reviews_rating; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_rating ON public."Reviews" USING btree (rating) WITH (deduplicate_items='true');


--
-- TOC entry 4652 (class 1259 OID 16434)
-- Name: idx_reviews_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_reviews_timestamp ON public."Reviews" USING btree ("timestamp") WITH (deduplicate_items='true');


-- Completed on 2025-02-21 17:58:54

--
-- PostgreSQL database dump complete
--

